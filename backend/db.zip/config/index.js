require("dotenv").config();
module.exports = process.env;
